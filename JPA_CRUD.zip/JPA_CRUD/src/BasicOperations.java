import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class BasicOperations {
	public static void main(String[] args){
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		Employee1 emp=new Employee1();
		emp.setDesignation("Programmer");
		emp.setEmpId(25);
		emp.setLocation("Hyderabad");
		emp.setName("Hari Krishna");
		
		em.getTransaction().begin();
		em.persist(emp);
		em.getTransaction().commit();
		System.out.println("Record inserted");
	}
}
